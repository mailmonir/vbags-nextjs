(() => {
var exports = {};
exports.id = 214;
exports.ids = [214];
exports.modules = {

/***/ 1366:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ gallery),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: external "lightgallery/react"
const react_namespaceObject = require("lightgallery/react");
var react_default = /*#__PURE__*/__webpack_require__.n(react_namespaceObject);
// EXTERNAL MODULE: ./lib/api.js
var api = __webpack_require__(7851);
// EXTERNAL MODULE: ./components/banner.js
var banner = __webpack_require__(5783);
// EXTERNAL MODULE: ./components/breadcrumb.js
var breadcrumb = __webpack_require__(2834);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./components/layout.js + 7 modules
var layout = __webpack_require__(5967);
// EXTERNAL MODULE: ./node_modules/lightgallery/css/lightgallery.css
var lightgallery = __webpack_require__(3527);
// EXTERNAL MODULE: ./node_modules/lightgallery/css/lg-zoom.css
var lg_zoom = __webpack_require__(8299);
// EXTERNAL MODULE: ./node_modules/lightgallery/css/lg-thumbnail.css
var lg_thumbnail = __webpack_require__(5563);
;// CONCATENATED MODULE: external "lightgallery/plugins/thumbnail"
const thumbnail_namespaceObject = require("lightgallery/plugins/thumbnail");
var thumbnail_default = /*#__PURE__*/__webpack_require__.n(thumbnail_namespaceObject);
;// CONCATENATED MODULE: external "lightgallery/plugins/zoom"
const zoom_namespaceObject = require("lightgallery/plugins/zoom");
var zoom_default = /*#__PURE__*/__webpack_require__.n(zoom_namespaceObject);
;// CONCATENATED MODULE: ./pages/gallery.js








// import styles



// import plugins if you need


const Gallery = ({ galleryPageData  })=>{
    const gImgs = galleryPageData?.page?.galleryPage?.galleryImages;
    const header = galleryPageData?.myOptionsPage?.header;
    const footer = galleryPageData?.myOptionsPage?.footer;
    const info = galleryPageData?.myOptionsPage?.info;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        header: header,
        footer: footer,
        info: info,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Gallery | Vicbor Bags BD Limited"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "og:title",
                        content: "Vicbor Bags BD Limited"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "https://victorbagsbd.com/gallery"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(banner/* default */.Z, {
                title: galleryPageData?.page?.title,
                image: galleryPageData?.page?.featuredImage?.node
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(breadcrumb/* default */.Z, {
                bcitems: [
                    {
                        text: "Gallery",
                        link: ""
                    }
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                className: "gallery u-offset-x",
                children: /*#__PURE__*/ jsx_runtime_.jsx((react_default()), {
                    elementClassNames: "gallery__light-gallery",
                    plugins: [
                        (zoom_default()),
                        (thumbnail_default())
                    ],
                    children: gImgs.map((img, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                            href: img.sourceUrl,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                alt: img.altText,
                                src: img.sourceUrl,
                                className: "gallery__image",
                                fill: true
                            })
                        }, index))
                })
            })
        ]
    });
};
/* harmony default export */ const gallery = (Gallery);
async function getStaticProps() {
    const galleryPageData = await (0,api/* getGalleryPageData */.QT)();
    return {
        props: {
            galleryPageData: galleryPageData || {}
        },
        revalidate: 10
    };
}


/***/ }),

/***/ 5563:
/***/ (() => {



/***/ }),

/***/ 8299:
/***/ (() => {



/***/ }),

/***/ 3527:
/***/ (() => {



/***/ }),

/***/ 3257:
/***/ ((module) => {

"use strict";
module.exports = require("algoliasearch/lite");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 7929:
/***/ ((module) => {

"use strict";
module.exports = require("react-instantsearch-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,157,685,714], () => (__webpack_exec__(1366)));
module.exports = __webpack_exports__;

})();