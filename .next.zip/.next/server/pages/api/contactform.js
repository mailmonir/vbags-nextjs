"use strict";
(() => {
var exports = {};
exports.id = 107;
exports.ids = [107];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 6507:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function sendEmail(req, res) {
    if (req.method === "POST") {
        try {
            fetch("https://hcaptcha.com/siteverify", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `secret=${process.env.HCAPTCHA_SECRET_KEY}&response=${req.body.token}`
            }).then((hCaptchaRes)=>hCaptchaRes.json()).then((hCaptchaRes)=>{
                console.log(hCaptchaRes, "Response from hCaptcha  verification API");
                if (hCaptchaRes?.success === true) {
                    let nodemailer = __webpack_require__(5184);
                    const transporter = nodemailer.createTransport({
                        port: 465,
                        host: "mail.victorbagsbd.com",
                        auth: {
                            user: "contactform@victorbagsbd.com",
                            pass: process.env.MAIL_PASSWORD
                        },
                        secure: true
                    });
                    const msg = {
                        to: req.body.email,
                        from: "contactform@victorbagsbd.com",
                        subject: `Message From ${req.body.formData.name}`,
                        text: req.body.formData.message + " | Sent from: " + req.body.formData.email,
                        html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`
                    };
                    transporter.sendMail(msg).then(()=>{
                        return res.status(200).json({
                            status: "success"
                        });
                    }).catch((err)=>{
                        return res.status(err.statusCode || 500).json({
                            error: err.message
                        });
                    });
                } else {
                    res.status(500).json({
                        status: "failure",
                        message: "HCaptcha Failure"
                    });
                }
            });
        } catch (err) {
            res.status(405).json({
                status: "failure",
                message: "Error submitting the enquiry form"
            });
        }
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sendEmail);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6507));
module.exports = __webpack_exports__;

})();