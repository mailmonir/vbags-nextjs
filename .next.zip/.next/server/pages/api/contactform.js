"use strict";
(() => {
var exports = {};
exports.id = 107;
exports.ids = [107];
exports.modules = {

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 9648:
/***/ ((module) => {

module.exports = import("axios");;

/***/ }),

/***/ 6507:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(9648);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([axios__WEBPACK_IMPORTED_MODULE_0__]);
axios__WEBPACK_IMPORTED_MODULE_0__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];

async function sendEmail(req, res) {
    console.log(req.body);
    if (req.method === "POST") {
        const { data  } = await axios__WEBPACK_IMPORTED_MODULE_0__["default"].post("https://www.google.com/recaptcha/api/siteverify", {
            secret: process.env.CAPTCHA_SECRET_KEY,
            response: req.body.token
        }, {
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            }
        });
        if (data.score >= 0.5) {
            let nodemailer = __webpack_require__(5184);
            const transporter = nodemailer.createTransport({
                port: 465,
                host: "mail.victorbagsbd.com",
                auth: {
                    user: "contactform@victorbagsbd.com",
                    pass: process.env.MAIL_PASSWORD
                },
                secure: true
            });
            const msg = {
                to: req.body.email,
                from: "contactform@victorbagsbd.com",
                subject: `Message From ${req.body.formData.name}`,
                text: req.body.formData.message + " | Sent from: " + req.body.formData.email,
                html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`
            };
            transporter.sendMail(msg, (err, info)=>{
                if (err) {
                    console.log(err);
                    res.status(500).json({
                        err: err
                    });
                } else {
                    console.log(info);
                    res.status(200).json({
                        success: info
                    });
                }
            });
        } else {
            res.status(500).json({
                status: "failure",
                message: "HCaptcha Failure"
            });
        }
    } else {
        res.status(405);
        res.end();
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sendEmail);

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6507));
module.exports = __webpack_exports__;

})();