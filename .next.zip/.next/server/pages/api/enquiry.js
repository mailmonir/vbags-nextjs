"use strict";
(() => {
var exports = {};
exports.id = 81;
exports.ids = [81];
exports.modules = {

/***/ 2139:
/***/ ((module) => {

module.exports = require("@sendgrid/mail");

/***/ }),

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 1290:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
const handler = (req, res)=>{
    (__webpack_require__(5142).config)();
    // let nodemailer = require("nodemailer");
    // console.log(process.env.CAPTCHA_SECRET_KEY);
    // if (req.method === "POST") {
    //   try {
    //     fetch("https://www.google.com/recaptcha/api/siteverify", {
    //       method: "POST",
    //       headers: {
    //         "Content-Type": "application/x-www-form-urlencoded",
    //       },
    //       body: `secret=${process.env.CAPTCHA_SECRET_KEY}&response=${req.body.gRecaptchaToken}`,
    //     })
    //       .then((reCaptchaRes) => reCaptchaRes.json())
    //       .then((reCaptchaRes) => {
    //         console.log(
    //           reCaptchaRes,
    //           "Response from Google reCatpcha verification API"
    //         );
    //         if (reCaptchaRes?.score > 0.05) {
    // const transporter = nodemailer.createTransport({
    //   port: 465,
    //   host: "mail.victorbagsbd.com",
    //   auth: {
    //     user: "contactform@victorbagsbd.com",
    //     pass: process.env.MAIL_PASSWORD,
    //   },
    //   secure: true,
    // });
    // const mailData = {
    //   from: "contactform@victorbagsbd.com",
    //   to: req.body.email,
    //   subject: `Message From ${req.body.formData.name}`,
    //   text:
    //     req.body.formData.message + " | Sent from: " + req.body.formData.email,
    //   html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`,
    // };
    // transporter.sendMail(mailData, function (err, info) {
    //   if (err) {
    //     res.status(501).json({
    //       status: "failure",
    //       message: "Enquiry submission failed",
    //     });
    //   } else {
    //     res.status(200).json({
    //       status: "success",
    //       message: "Enquiry submitted successfully",
    //     });
    //   }
    // });
    //         } else {
    //           res.status(500).json({
    //             status: "failure",
    //             message: "Google ReCaptcha Failure",
    //           });
    //         }
    //       });
    //   } catch (err) {
    //     res.status(405).json({
    //       status: "failure",
    //       message: "Error submitting the enquiry form",
    //     });
    //   }
    // } else {
    //   res.status(405);
    //   res.end();
    // }
    // using Twilio SendGrid's v3 Node.js Library
    // https://github.com/sendgrid/sendgrid-nodejs
    const sgMail = __webpack_require__(2139);
    sgMail.setApiKey(process.env.SENDGRID_API_KEY);
    const msg = {
        to: req.body.email,
        from: "contactform@victorbagsbd.com",
        subject: `Message From ${req.body.formData.name}`,
        text: req.body.formData.message + " | Sent from: " + req.body.formData.email,
        html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`
    };
    sgMail.send(msg).then(()=>{
        console.log("Email sent");
        res.status(200).json({
            status: "success",
            message: "Enquiry submitted successfully"
        });
    }).catch((error)=>{
        console.error(error);
        res.status(500).json({
            status: "success",
            message: "Email sending filed"
        });
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (handler);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(1290));
module.exports = __webpack_exports__;

})();