"use strict";
(() => {
var exports = {};
exports.id = 442;
exports.ids = [442];
exports.modules = {

/***/ 3257:
/***/ ((module) => {

module.exports = require("algoliasearch/lite");

/***/ }),

/***/ 5079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ api_algolia)
});

;// CONCATENATED MODULE: ./lib/api.js
const API_URL = process.env.WORDPRESS_API_URL;
async function fetchAPI(query, { variables  } = {}) {
    const headers = {
        "Content-Type": "application/json"
    };
    if (process.env.WORDPRESS_AUTH_REFRESH_TOKEN) {
        headers["Authorization"] = `Bearer ${process.env.WORDPRESS_AUTH_REFRESH_TOKEN}`;
    }
    const res = await fetch(API_URL, {
        method: "POST",
        headers,
        body: JSON.stringify({
            query,
            variables
        })
    });
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error("Failed to fetch API");
    }
    return json.data;
}
async function getFactoryPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
  
          }
          logoWhite {
            altText
            sourceUrl
  
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
  
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "70", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
  
          }
        }
        title
        galleryPage {
          galleryImages {
            altText
            sourceUrl
  
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getAboutPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
  
          }
          logoWhite {
            altText
            sourceUrl
  
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
  
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "63", idType: DATABASE_ID) {
        aboutPage {
          aboutUs
          mdSpeech
        }
        title
        featuredImage {
          node {
            altText
            sourceUrl
  
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getContactPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            contactFormEmailRece
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
  
          }
          logoWhite {
            altText
            sourceUrl
  
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
  
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "65", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
  
          }
        }
        title
        contactPage {
          contactHeading
          contactDescription
          addressHeadOffice
          addressFactory
          addressChinaOffice
          contactFormHeading
          contactFormMessage
          contactFormImage {
            altText
            sourceUrl
  
          }
          locationHeading
          gmap {
            city
            country
            postCode
            state
            streetAddress
            stateShort
            streetName
            streetNumber
            countryShort
            latitude
            longitude
            placeId
            zoom
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getProducts() {
    const data = await fetchAPI(`
    query NewQuery {
      
      page(id: "67", idType: DATABASE_ID) {
        productsPage {
          products {
            productDescription
            productName
            productImage {
              altText
              sourceUrl
    
            }
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getProductsPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
  
          }
          logoWhite {
            altText
            sourceUrl
  
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
  
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "67", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
  
          }
        }
        productsPage {
          products {
            productDescription
            productName
            productImage {
              altText
              sourceUrl
    
            }
          }
        }
        title
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getMainPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
  
          }
          logoWhite {
            altText
            sourceUrl
  
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
        
      }
      pages(where: {id: 67}) {
        nodes {
          productsPage {
            products {
              productName
              productDescription
              productImage {
                altText
                sourceUrl
      
              }
              showOnFrontPage
            }
          }
        }
      }
      page(id: "60", idType: DATABASE_ID) {
        mainPage {
          slides {
            buttonText
            buttonLink
            mainHeading
            subHeading
            slideImage {
              altText
              sourceUrl
    
            }
          }
          productsHeading
          
          certificationsHeading
          about {
            aboutUsText
            aboutUsImage {
              altText
              sourceUrl
    
            }
            aboutheading
          }
          certifications {
            image {
              altText
              sourceUrl
    
            }
          }
          watermarkImage {
            altText
            sourceUrl
  
          }
        }
      }
      
    }
  `, {
        variables: {}
    });
    return data || {};
}

;// CONCATENATED MODULE: ./pages/api/algolia.js
const algoliaSearch = __webpack_require__(3257);

function transformProductsToSearchObjects(products) {
    const transformed = products.map((product, index)=>{
        return {
            objectID: index,
            productName: product.productName,
            productDescription: product.productDescription.replace(/(<([^>]+)>)/gi, "").replace(/\n/g, ""),
            productImage: {
                altText: product?.productImage?.altText,
                sourceUrl: product?.productImage?.sourceUrl
            }
        };
    });
    return transformed;
}
const algolia = async (req, res)=>{
    try {
        const data = await getProducts();
        const products = data?.page?.productsPage?.products;
        const transformed = transformProductsToSearchObjects(products);
        const client = algoliaSearch("MKA5ILPDAS", process.env.ALGOLIA_ADMIN_KEY);
        const index = client.initIndex("victorbags");
        index.clearObjects().then(()=>{
            index.saveObjects(transformed);
        });
        res.status(200).json({
            status: "success",
            message: "Data sending to algolia successful"
        });
    } catch (error) {
        res.status(500).json({
            status: "fail",
            message: "Data sending failed to algolia"
        });
    }
};
/* harmony default export */ const api_algolia = (algolia);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(5079));
module.exports = __webpack_exports__;

})();