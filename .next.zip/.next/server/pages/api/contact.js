"use strict";
(() => {
var exports = {};
exports.id = 91;
exports.ids = [91];
exports.modules = {

/***/ 5142:
/***/ ((module) => {

module.exports = require("dotenv");

/***/ }),

/***/ 5184:
/***/ ((module) => {

module.exports = require("nodemailer");

/***/ }),

/***/ 558:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ contactFormApi)
/* harmony export */ });
function contactFormApi(req, res) {
    (__webpack_require__(5142).config)();
    let nodemailer = __webpack_require__(5184);
    const transporter = nodemailer.createTransport({
        port: 465,
        host: "mail.victorbagsbd.com",
        auth: {
            user: "contactform@victorbagsbd.com",
            pass: process.env.MAIL_PASSWORD
        },
        secure: true
    });
    const mailData = {
        from: "contactform@victorbagsbd.com",
        to: req.body.email,
        subject: `Message From ${req.body.formData.name}`,
        text: req.body.formData.message + " | Sent from: " + req.body.formData.email,
        html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`
    };
    transporter.sendMail(mailData, function(err, info) {
        if (err) {
            console.log(err);
            res.send("error");
        } else {
            console.log(info);
            res.send("success");
        }
    });
}


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(558));
module.exports = __webpack_exports__;

})();