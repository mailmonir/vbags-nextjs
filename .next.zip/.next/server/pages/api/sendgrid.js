"use strict";
(() => {
var exports = {};
exports.id = 845;
exports.ids = [845];
exports.modules = {

/***/ 6272:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ sendgrid)
});

;// CONCATENATED MODULE: external "@sendgrid/mail"
const mail_namespaceObject = require("@sendgrid/mail");
var mail_default = /*#__PURE__*/__webpack_require__.n(mail_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/sendgrid.js

mail_default().setApiKey(process.env.SENDGRID_API_KEY);
function sendEmail(req, res) {
    if (req.method === "POST") {
        try {
            fetch("https://hcaptcha.com/siteverify", {
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                },
                body: `secret=${process.env.HCAPTCHA_SECRET_KEY}&response=${req.body.token}`
            }).then((hCaptchaRes)=>hCaptchaRes.json()).then((hCaptchaRes)=>{
                console.log(hCaptchaRes, "Response from hCaptcha  verification API");
                if (hCaptchaRes?.success === true) {
                    const msg = {
                        to: req.body.email,
                        from: "contactform@victorbagsbd.com",
                        subject: `Message From ${req.body.formData.name}`,
                        text: req.body.formData.message + " | Sent from: " + req.body.formData.email,
                        html: `<div>${req.body.formData.message}</div><p>Sent from: ${req.body.formData.email}</p>`
                    };
                    mail_default().send(msg).then(()=>{
                        return res.status(200).json({
                            error: ""
                        });
                    }).catch(()=>{
                        return res.status(error.statusCode || 500).json({
                            error: error.message
                        });
                    });
                } else {
                    res.status(500).json({
                        status: "failure",
                        message: "Google ReCaptcha Failure"
                    });
                }
            });
        } catch (err) {
            res.status(405).json({
                status: "failure",
                message: "Error submitting the enquiry form"
            });
        }
    } else {
        res.status(405);
        res.end();
    }
}
/* harmony default export */ const sendgrid = (sendEmail);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(6272));
module.exports = __webpack_exports__;

})();