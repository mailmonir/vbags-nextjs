(() => {
var exports = {};
exports.id = 405;
exports.ids = [405];
exports.modules = {

/***/ 1814:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_555963', '__Inter_Fallback_555963'","fontStyle":"normal"},
	"className": "__className_555963"
};


/***/ }),

/***/ 1591:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_555963', '__Inter_Fallback_555963'","fontStyle":"normal"},
	"className": "__className_555963"
};


/***/ }),

/***/ 6235:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_555963', '__Inter_Fallback_555963'","fontStyle":"normal"},
	"className": "__className_555963"
};


/***/ }),

/***/ 3549:
/***/ ((module) => {

// Exports
module.exports = {
	"style": {"fontFamily":"'__Inter_555963', '__Inter_Fallback_555963'","fontStyle":"normal"},
	"className": "__className_555963"
};


/***/ }),

/***/ 9203:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ pages),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"components\\slider.js","import":"Inter","arguments":[],"variableName":"inter"}
var target_path_components_slider_js_import_Inter_arguments_variableName_inter_ = __webpack_require__(3549);
var target_path_components_slider_js_import_Inter_arguments_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_components_slider_js_import_Inter_arguments_variableName_inter_);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/keen-slider/keen-slider.min.css
var keen_slider_min = __webpack_require__(6443);
;// CONCATENATED MODULE: external "keen-slider/react"
const react_namespaceObject = require("keen-slider/react");
;// CONCATENATED MODULE: ./components/slider.js






function BgSlider({ slides  }) {
    const [sliderRef] = (0,react_namespaceObject.useKeenSlider)({
        loop: true
    }, [
        (slider)=>{
            let timeout;
            let mouseOver = false;
            function clearNextTimeout() {
                clearTimeout(timeout);
            }
            function nextTimeout() {
                clearTimeout(timeout);
                if (mouseOver) return;
                timeout = setTimeout(()=>{
                    slider.next();
                }, 5000);
            }
            slider.on("created", ()=>{
                slider.container.addEventListener("mouseover", ()=>{
                    mouseOver = true;
                    clearNextTimeout();
                });
                slider.container.addEventListener("mouseout", ()=>{
                    mouseOver = false;
                    nextTimeout();
                });
                nextTimeout();
            });
            slider.on("dragStarted", clearNextTimeout);
            slider.on("animationEnded", nextTimeout);
            slider.on("updated", nextTimeout);
        }
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ref: sliderRef,
        className: "keen-slider",
        children: slides && slides.map((slide, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "keen-slider__slide",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: slide?.slideImage?.sourceUrl,
                        alt: slide?.slideImage?.altText,
                        className: "slider-image",
                        fill: true,
                        sizes: "100vw",
                        priority: index === 0
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "overlay",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "overlay__text-box",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                    className: `heading-primary ${(target_path_components_slider_js_import_Inter_arguments_variableName_inter_default()).className}`,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "heading-primary--main",
                                            children: slide?.mainHeading
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            className: "heading-primary--sub",
                                            children: slide?.subHeading
                                        })
                                    ]
                                }),
                                slide.buttonText && /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: slide?.buttonLink,
                                    className: "btn btn--white btn--animated",
                                    children: slide?.buttonText
                                })
                            ]
                        })
                    })
                ]
            }, index))
    });
}

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"components\\certifications.js","import":"Inter","arguments":[],"variableName":"inter"}
var target_path_components_certifications_js_import_Inter_arguments_variableName_inter_ = __webpack_require__(6235);
var target_path_components_certifications_js_import_Inter_arguments_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_components_certifications_js_import_Inter_arguments_variableName_inter_);
;// CONCATENATED MODULE: ./components/certifications.js



function Certifications({ certifications , heading  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "certifications",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "u-center-text u-margin-bottom-big",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: `heading-secondary ${(target_path_components_certifications_js_import_Inter_arguments_variableName_inter_default()).className}`,
                    children: heading
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "certifications__item-wrapper",
                children: certifications && certifications.map((cimg, index)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "certifications__item",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: cimg?.image?.sourceUrl,
                            alt: cimg?.image?.altText,
                            className: "certifications__image",
                            width: 600,
                            height: 400
                        })
                    }, index))
            })
        ]
    });
}

// EXTERNAL MODULE: ./components/layout.js + 7 modules
var layout = __webpack_require__(5967);
// EXTERNAL MODULE: ./lib/api.js
var api = __webpack_require__(7851);
// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"components\\categories.js","import":"Inter","arguments":[],"variableName":"inter"}
var target_path_components_categories_js_import_Inter_arguments_variableName_inter_ = __webpack_require__(1591);
var target_path_components_categories_js_import_Inter_arguments_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_components_categories_js_import_Inter_arguments_variableName_inter_);
;// CONCATENATED MODULE: ./components/categories.js




const Categories = ({ products , heading , wmImage  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "categories",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "u-center-text u-margin-bottom-big",
                children: /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: `heading-secondary ${(target_path_components_categories_js_import_Inter_arguments_variableName_inter_default()).className}`,
                    children: heading
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "categories__items",
                children: products.map((product, index)=>/*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "products",
                        className: "categories__item",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: product?.productImage?.sourceUrl,
                            alt: product?.productImage?.altText,
                            className: "categories__image",
                            width: 600,
                            height: 700
                        })
                    }, index))
            })
        ]
    });
};
/* harmony default export */ const categories = (Categories);

// EXTERNAL MODULE: ./node_modules/@next/font/google/target.css?{"path":"components\\about.js","import":"Inter","arguments":[],"variableName":"inter"}
var target_path_components_about_js_import_Inter_arguments_variableName_inter_ = __webpack_require__(1814);
var target_path_components_about_js_import_Inter_arguments_variableName_inter_default = /*#__PURE__*/__webpack_require__.n(target_path_components_about_js_import_Inter_arguments_variableName_inter_);
;// CONCATENATED MODULE: ./components/about.js





const About = ({ data  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("section", {
        className: "about-section",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "about-section__content",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: `heading-secondary heading-secondary--white ${(target_path_components_about_js_import_Inter_arguments_variableName_inter_default()).className}`,
                    children: data?.aboutheading
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "info",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "info__text",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: data?.aboutUsText
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                    href: "about",
                                    className: "btn btn--red info__button",
                                    children: "More about us"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "info__image-wrapper",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: data?.aboutUsImage?.sourceUrl,
                                alt: data?.aboutUsImage?.altText,
                                className: "info__image",
                                width: 1280,
                                height: 862
                            })
                        })
                    ]
                })
            ]
        })
    });
};
/* harmony default export */ const about = (About);

// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
;// CONCATENATED MODULE: ./pages/index.js









const Home = ({ mainPageData  })=>{
    const header = mainPageData?.myOptionsPage?.header;
    const footer = mainPageData?.myOptionsPage?.footer;
    const info = mainPageData?.myOptionsPage?.info;
    const products = mainPageData?.pages?.nodes[0]?.productsPage?.products.filter((item)=>item.showOnFrontPage === true);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(layout/* default */.Z, {
        header: header,
        footer: footer,
        info: info,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Home | Vicbor Bags BD Limited"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "og:title",
                        content: "Vicbor Bags BD Limited"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:type",
                        content: "image"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:url",
                        content: "https://victorbagsbd.com/"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        property: "og:image",
                        content: "https://victorbagsbd.com/_next/image?url=https%3A%2F%2Fvictorbagsbd.com%2Fadmin%2Fwp-content%2Fuploads%2F2023%2F01%2Fslider-one.jpg&w=1920&q=75"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "home-page-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(BgSlider, {
                        slides: mainPageData?.page?.mainPage?.slides
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(categories, {
                        products: products,
                        heading: mainPageData?.page?.mainPage?.productsHeading,
                        wmImage: mainPageData?.page?.mainPage?.watermarkImage
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(about, {
                        data: mainPageData?.page?.mainPage?.about
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Certifications, {
                        certifications: mainPageData?.page?.mainPage?.certifications,
                        heading: mainPageData?.page?.mainPage?.certificationsHeading
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const pages = (Home);
async function getStaticProps() {
    const mainPageData = await (0,api/* getMainPageData */.yc)();
    return {
        props: {
            mainPageData: mainPageData || {}
        },
        revalidate: 10
    };
}


/***/ }),

/***/ 6443:
/***/ (() => {



/***/ }),

/***/ 3257:
/***/ ((module) => {

"use strict";
module.exports = require("algoliasearch/lite");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 5832:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/loadable.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

"use strict";
module.exports = require("next/head");

/***/ }),

/***/ 1853:
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ 6689:
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ 6405:
/***/ ((module) => {

"use strict";
module.exports = require("react-dom");

/***/ }),

/***/ 6290:
/***/ ((module) => {

"use strict";
module.exports = require("react-icons/fa");

/***/ }),

/***/ 7929:
/***/ ((module) => {

"use strict";
module.exports = require("react-instantsearch-dom");

/***/ }),

/***/ 997:
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [121,676,157,685], () => (__webpack_exec__(9203)));
module.exports = __webpack_exports__;

})();