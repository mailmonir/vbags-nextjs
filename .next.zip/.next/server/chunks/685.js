"use strict";
exports.id = 685;
exports.ids = [685];
exports.modules = {

/***/ 5967:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
// EXTERNAL MODULE: external "react-icons/fa"
var fa_ = __webpack_require__(6290);
// EXTERNAL MODULE: external "react-dom"
var external_react_dom_ = __webpack_require__(6405);
// EXTERNAL MODULE: external "algoliasearch/lite"
var lite_ = __webpack_require__(3257);
var lite_default = /*#__PURE__*/__webpack_require__.n(lite_);
// EXTERNAL MODULE: external "react-instantsearch-dom"
var external_react_instantsearch_dom_ = __webpack_require__(7929);
;// CONCATENATED MODULE: ./components/customSearchBox.js



const CustomSearchBox = ({ refine  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
        action: "",
        role: "search",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                id: "algolia_search",
                type: "search",
                placeholder: "Product search",
                onChange: (e)=>refine(e.currentTarget.value),
                className: "form__input"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "search-icon",
                children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaSearch, {})
            })
        ]
    });
};
/* harmony default export */ const customSearchBox = ((0,external_react_instantsearch_dom_.connectSearchBox)(CustomSearchBox));

// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
var dynamic_default = /*#__PURE__*/__webpack_require__.n(dynamic);
;// CONCATENATED MODULE: ./components/customHits.js



const IsoProducts = dynamic_default()(null, {
    loadableGenerated: {
        modules: [
            "..\\components\\customHits.js -> " + "../components/isoproducts"
        ]
    },
    ssr: false
});
function CustomHits({ searchState , searchResults  }) {
    const validQuery = searchState.query?.length >= 3;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            searchResults?.hits.length === 0 && validQuery && /*#__PURE__*/ jsx_runtime_.jsx("p", {
                children: "Aw snap! Nothing found."
            }),
            searchResults?.hits.length > 0 && validQuery && /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(IsoProducts, {
                    products: searchResults.hits,
                    cname: "modal-cards"
                })
            })
        ]
    });
}
/* harmony default export */ const customHits = ((0,external_react_instantsearch_dom_.connectStateResults)(CustomHits));

;// CONCATENATED MODULE: ./components/modal.js





const searchClient = lite_default()("MKA5ILPDAS", "bdf75ffefdd11a30591117bd07d5b5e5");
const Modal = ({ onClose  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `modal`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "close",
                onClick: onClose,
                children: "\xd7"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_instantsearch_dom_.InstantSearch, {
                    searchClient: searchClient,
                    indexName: "victorbags",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(customSearchBox, {}),
                        /*#__PURE__*/ jsx_runtime_.jsx(customHits, {})
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const modal = (Modal);

;// CONCATENATED MODULE: ./components/navbar.js








const Navbar = ({ header  })=>{
    const [navUp, setNavUp] = external_react_default().useState(false);
    const [rotateBars, setRotateBars] = external_react_default().useState(false);
    const [openMenu, setOpenMenu] = external_react_default().useState(false);
    const [showModal, setShowModal] = external_react_default().useState(false);
    const router = (0,router_.useRouter)();
    external_react_default().useEffect(()=>{
        const handleScroll = (event)=>{
            window.scrollY > 10 ? setNavUp(true) : setNavUp(false);
        };
        window.addEventListener("scroll", handleScroll);
        return ()=>{
            window.removeEventListener("scroll", handleScroll);
        };
    }, []);
    const handlClick = ()=>{
        setRotateBars((state)=>!state);
        setOpenMenu((state)=>!state);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: `navbar ${navUp ? "float-nav" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                href: "/",
                children: header?.logoWhite?.sourceUrl ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "logo",
                            src: header?.logo?.sourceUrl,
                            alt: header?.logo?.altText,
                            width: 1691,
                            height: 364,
                            sizes: header?.logo?.srcSet
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            className: "logo-white",
                            src: header?.logoWhite?.sourceUrl,
                            alt: header?.logoWhite?.altText,
                            width: 1691,
                            height: 364,
                            sizes: header?.logoWhite?.srcSet
                        })
                    ]
                }) : /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                    className: "logo",
                    src: header?.logo?.sourceUrl,
                    alt: header?.logo?.altText,
                    width: 1691,
                    height: 364,
                    sizes: header?.logo?.srcSet
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `nav__button ${rotateBars ? "rotate-bars" : ""}`,
                onClick: handlClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                    className: "nav__icon",
                    children: "\xa0"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: `nav-wrapper ${openMenu ? "open" : ""}`,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                    className: "nav",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav__list-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                className: `nav__link ${router.pathname == "/" ? "active" : ""}`,
                                children: "Home"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav__list-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "products",
                                className: `nav__link ${router.pathname == "/products" ? "active" : ""}`,
                                children: "Products"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav__list-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "gallery",
                                className: `nav__link ${router.pathname == "/gallery" ? "active" : ""}`,
                                children: "Gallery"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav__list-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "about",
                                className: `nav__link ${router.pathname == "/about" ? "active" : ""}`,
                                children: "About"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("li", {
                            className: "nav__list-item",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "contact",
                                className: `nav__link ${router.pathname == "/contact" ? "active" : ""}`,
                                children: "Contact"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: ()=>setShowModal(true),
                        className: "search",
                        "aria-label": "Search",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaSearch, {})
                    }),
                    showModal && /*#__PURE__*/ (0,external_react_dom_.createPortal)(/*#__PURE__*/ jsx_runtime_.jsx(modal, {
                        onClose: ()=>setShowModal(false)
                    }), document.body)
                ]
            })
        ]
    });
};
/* harmony default export */ const navbar = (Navbar);

;// CONCATENATED MODULE: ./components/footer.js






const Footer = ({ footer  })=>{
    const router = (0,router_.useRouter)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "footer",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "footer__logobox",
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                        src: footer?.footerLogo?.sourceUrl,
                        alt: footer?.footerLogo?.altText,
                        className: "footer__logo",
                        width: 1691,
                        height: 364,
                        sizes: footer?.footerLogo?.srcSet
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "footer__middle",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer__navigation",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "footer__list",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "footer__item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/",
                                        className: `footer__link ${router.pathname == "/" ? "active" : ""}`,
                                        children: "Home"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "footer__item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "products",
                                        className: `footer__link ${router.pathname == "/products" ? "active" : ""}`,
                                        children: "Products"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "footer__item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "gallery",
                                        className: `footer__link ${router.pathname == "/gallery" ? "active" : ""}`,
                                        children: "Gallery"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "footer__item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "about",
                                        className: `footer__link ${router.pathname == "/about" ? "active" : ""}`,
                                        children: "About"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "footer__item",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "contact",
                                        className: `footer__link ${router.pathname == "/contact" ? "active" : ""}`,
                                        children: "Contact"
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer__text",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "footer__info",
                            children: footer?.footerText
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "footer__bottom",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "footer__copyright",
                        children: footer?.copyrightText
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "footer__list-social",
                        children: [
                            footer?.socialMedia?.facebookUrl && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "footer__item-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__link-social",
                                    href: footer?.socialMedia?.facebookUrl,
                                    children: [
                                        "Facebook",
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaFacebookF, {})
                                    ]
                                })
                            }),
                            footer?.socialMedia?.twitterUrl && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "footer__item-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__link-social",
                                    href: footer?.socialMedia?.twitterUrl,
                                    children: [
                                        "Twitter",
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaTwitter, {})
                                    ]
                                })
                            }),
                            footer?.socialMedia?.instagramUrl && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "footer__item-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__link-social",
                                    href: footer?.socialMedia?.instagramUrl,
                                    children: [
                                        "Instagram",
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaInstagram, {})
                                    ]
                                })
                            }),
                            footer?.socialMedia?.youtubeUrl && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "footer__item-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__link-social",
                                    href: footer?.socialMedia?.youtubeUrl,
                                    children: [
                                        "Youtube",
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaYoutube, {})
                                    ]
                                })
                            }),
                            footer?.socialMedia?.linkedinUrl && /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "footer__item-social",
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                    className: "footer__link-social",
                                    href: footer?.socialMedia?.linkedinUrl,
                                    children: [
                                        "Linkedin",
                                        /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaLinkedinIn, {})
                                    ]
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const components_footer = (Footer);

;// CONCATENATED MODULE: ./components/ScrollTop.js



const ScrollTop = ()=>{
    const [visible, setVisible] = (0,external_react_.useState)(false);
    const toggleVisible = ()=>{
        const scrolled = document.documentElement.scrollTop;
        if (scrolled > 300) {
            setVisible(true);
        } else if (scrolled <= 300) {
            setVisible(false);
        }
    };
    (0,external_react_.useEffect)(()=>{
        window.addEventListener("scroll", toggleVisible);
        return ()=>{
            window.removeEventListener("scroll", toggleVisible);
        };
    }, []);
    const scrollToTop = ()=>{
        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "scroll-top",
        style: {
            display: visible ? "inline-block" : "none"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaArrowCircleUp, {
            onClick: scrollToTop,
            className: "scroll-top__icon"
        })
    });
};
/* harmony default export */ const components_ScrollTop = (ScrollTop);

;// CONCATENATED MODULE: ./components/WhatsApp.js



const WhatsApp = ({ info  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("a", {
        href: `https://wa.me/${info?.settings?.whatsAppNumber}`,
        className: "whats-app",
        "aria-label": "Use whats app for online chatting",
        children: /*#__PURE__*/ jsx_runtime_.jsx(fa_.FaWhatsapp, {})
    });
};
/* harmony default export */ const components_WhatsApp = (WhatsApp);

;// CONCATENATED MODULE: ./components/layout.js








const Layout = ({ children , header , footer , info  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/favicon/favicon.ico"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Victor Leather Bags Factory Ltd. is a Bangladeshi manufacturing and exporting unit of backpack, laptop bag, hiking bag, luggage and ladies bag."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(navbar, {
                header: header
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("main", {
                children: children
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_footer, {
                footer: footer
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_ScrollTop, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(components_WhatsApp, {
                info: info
            })
        ]
    });
};
/* harmony default export */ const layout = (Layout);


/***/ }),

/***/ 7851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$D": () => (/* binding */ getProductsPageData),
/* harmony export */   "QT": () => (/* binding */ getGalleryPageData),
/* harmony export */   "bs": () => (/* binding */ getContactPageData),
/* harmony export */   "ir": () => (/* binding */ getAboutPageData),
/* harmony export */   "yc": () => (/* binding */ getMainPageData)
/* harmony export */ });
/* unused harmony export getProducts */
const API_URL = process.env.WORDPRESS_API_URL;
async function fetchAPI(query, { variables  } = {}) {
    const headers = {
        "Content-Type": "application/json"
    };
    if (process.env.WORDPRESS_AUTH_REFRESH_TOKEN) {
        headers["Authorization"] = `Bearer ${process.env.WORDPRESS_AUTH_REFRESH_TOKEN}`;
    }
    const res = await fetch(API_URL, {
        method: "POST",
        headers,
        body: JSON.stringify({
            query,
            variables
        })
    });
    const json = await res.json();
    if (json.errors) {
        console.error(json.errors);
        throw new Error("Failed to fetch API");
    }
    return json.data;
}
async function getGalleryPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
            srcSet
          }
          logoWhite {
            altText
            sourceUrl
            srcSet
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
            srcSet
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "70", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
            srcSet
          }
        }
        title
        galleryPage {
          galleryImages {
            altText
            sourceUrl
            srcSet
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getAboutPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
            srcSet
          }
          logoWhite {
            altText
            sourceUrl
            srcSet
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
            srcSet
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "63", idType: DATABASE_ID) {
        aboutPage {
          aboutUs
          mdSpeech
        }
        title
        featuredImage {
          node {
            altText
            sourceUrl
            srcSet
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getContactPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            contactFormEmailRece
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
            srcSet
          }
          logoWhite {
            altText
            sourceUrl
            srcSet
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
            srcSet
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "65", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
            srcSet
          }
        }
        title
        contactPage {
          contactHeading
          contactDescription
          addressHeadOffice
          addressFactory
          addressChinaOffice
          contactFormHeading
          contactFormMessage
          contactFormImage {
            altText
            sourceUrl
            srcSet
          }
          locationHeading
          gmap {
            city
            country
            postCode
            state
            streetAddress
            stateShort
            streetName
            streetNumber
            countryShort
            latitude
            longitude
            placeId
            zoom
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getProducts() {
    const data = await fetchAPI(`
    query NewQuery {
      
      page(id: "67", idType: DATABASE_ID) {
        productsPage {
          products {
            productDescription
            productName
            productImage {
              altText
              sourceUrl
              srcSet
            }
          }
        }
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getProductsPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
            srcSet
          }
          logoWhite {
            altText
            sourceUrl
            srcSet
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
            srcSet
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
      }
      page(id: "67", idType: DATABASE_ID) {
        featuredImage {
          node {
            altText
            sourceUrl
            srcSet
          }
        }
        productsPage {
          products {
            productDescription
            productName
            productImage {
              altText
              sourceUrl
              srcSet
            }
          }
        }
        title
      }
    }
  `, {
        variables: {}
    });
    return data || {};
}
async function getMainPageData() {
    const data = await fetchAPI(`
    query NewQuery {
      myOptionsPage {
        info {
          settings {
            whatsAppNumber
          }
        }
        header {
          logo {
            altText
            sourceUrl
            srcSet
          }
          logoWhite {
            altText
            sourceUrl
            srcSet
          }
        }
        footer {
          footerLogo {
            altText
            sourceUrl
          }
          copyrightText
          footerText
          socialMedia {
            facebookUrl
            instagramUrl
            linkedinUrl
            twitterUrl
            youtubeUrl
          }
        }
        
      }
      pages(where: {id: 67}) {
        nodes {
          productsPage {
            products {
              productName
              productDescription
              productImage {
                altText
                sourceUrl
                srcSet
              }
              showOnFrontPage
            }
          }
        }
      }
      page(id: "60", idType: DATABASE_ID) {
        mainPage {
          slides {
            buttonText
            buttonLink
            mainHeading
            subHeading
            slideImage {
              altText
              sourceUrl
              srcSet
            }
          }
          productsHeading
          
          certificationsHeading
          about {
            aboutUsText
            aboutUsImage {
              altText
              sourceUrl
              srcSet
            }
            aboutheading
          }
          certifications {
            image {
              altText
              sourceUrl
              srcSet
            }
          }
          watermarkImage {
            altText
            sourceUrl
            srcSet
          }
        }
      }
      
    }
  `, {
        variables: {}
    });
    return data || {};
}


/***/ })

};
;